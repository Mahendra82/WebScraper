/**
 * Package contains application class invoking WebScraper 
 * 
 */
/**
 * @author MJ
 *
 */
package com.gr.scraper.application;