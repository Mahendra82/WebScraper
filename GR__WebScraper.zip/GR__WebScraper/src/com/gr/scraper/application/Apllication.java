package com.gr.scraper.application;

import com.gr.scraper.WebScraper;

public class Apllication
{

	
	public static void main(String[] args)
	{

		new WebScraper().getJson();
	}
}
