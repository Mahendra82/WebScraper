/**
 * This package contains core logic to generate the JSON object. 
 *  IWebscrpaer is the interface and WebScraper contains the implementation.
 *  All the required fields will be bundled in Web object and the Json object will be created.
 */
/**
 * @author MJ
 *
 */
package com.gr.scraper;